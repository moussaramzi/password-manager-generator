import "./App.css";
import { useState, useEffect} from "react";
import Axios from "axios";
import axios from "axios";



//password generator
 
const CHARS =
"0123456789abcdefghijklmnopqrstuvwxyz!@#$%^&*()ABCDEFGHIJKLMNOPQRSTUVWXYZ";

/**
* Curried function that returns a random char of the given string.
* @param {string} chars
*/
const randomCharacter = (chars) => () =>
chars[Math.floor(Math.random() * chars.length)];

/**
* Curried function that returns a string of random chars of the given string.
* @param {string} chars
*/
const generatePassword = (chars) =>
/** @param {number} length */
(length) => () => [...Array(length)].map(randomCharacter(chars)).join("");

/** @type {HTMLInputElement} */
const passwordInput = document.querySelector("#password");
const generatePasswordChars = generatePassword(CHARS);
const generatePasswordChars18 = generatePasswordChars(18);

document.querySelector("#generate-button").addEventListener("click", () => {
passwordInput.value = generatePasswordChars18();
});

document.querySelector("#copy-button").addEventListener("click", () => {
navigator.clipboard
  .writeText(passwordInput.value)
  .catch(() =>
    console.error("Can't copy (you need to open this in its own window).")
  );
});




//password manager
function App() {
  const [password, setPassword] = useState("");
  const [title, setTitle] = useState("");
  const [passwordList, setPasswordList] = useState([]);
 

  
  
useEffect( () =>{
  axios.get("http://localhost:3001/showpasswords").then((response)=>{
    setPasswordList(response.data)

  });
}, []);

  const addPassword = () => {
    Axios.post("http://localhost:3001/addpassword", {
      password: password,
      title: title,
    });
  };

  const decryptPassword = (encryption) =>{
    axios.post("http://localhost:3001/decryptpassword", {
      password: encryption.password,
       iv: encryption.iv,
      }).then((response)=>{
        setPasswordList(passwordList.map((val)=>{
          return val.id === encryption.id ? {id: val.id, password: val.password, title: response.data, iv: val.iv} : val
        }))
      });
  }

  return (
    <div className="App">
      <div className="AddingPassword">
        <h2> Password manager</h2>
        
        <input
          type="text"
          placeholder="Ex. Facebook"
          onChange={(event) => {
            setTitle(event.target.value);
          }}
        />
        <input
          type="password"
          placeholder="Ex. password123"
          onChange={(event) => {
            setPassword(event.target.value);
          }}
        />
        <button onClick={addPassword}> Add Password</button>
      </div>
      <div className="passwords">
        {passwordList.map((val, key) =>{
          return (
          <div className="password" onClick={()=>{decryptPassword({password: val.password, iv: val.iv, id: val.id})
          }} key={key}>
            <h3>{val.title}</h3>
          </div>
          );
        })}

      </div>

     
    </div>
  );
}

export default App;